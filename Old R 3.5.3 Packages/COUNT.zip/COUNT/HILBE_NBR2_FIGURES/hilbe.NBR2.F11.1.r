# hilbe.NBR2.F11.1.r
# From Hilbe, Negative Binomial regression, 2nd ed, Cambridge Univ. Press
# FIGURE 11.1
load("c://source/mdvis.RData")
histogram(mdvis$numvisit)



