# ggmosaic 0.0.1


## Brand New Features

## Small Usage Changes

- discontinued use of separators
- `alpha` is recognized as aesthetic

## Other changes

- `product` function is changed to wrapper of `list`.

